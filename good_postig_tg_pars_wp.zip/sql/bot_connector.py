from sql.bd import BotDB
BotDB = BotDB("monit.db")

