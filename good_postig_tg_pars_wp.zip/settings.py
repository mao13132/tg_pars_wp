CHANNELS_AND_SITE = [
    {
        'name': 'Кубинка',
        'channels': ['https://t.me/Svetofor_Kubinka'],
        'category': 'Светофор',
        'sites': [
            {
                'site': 'https://kubinka-today.ru/v355/',
                'login': 'Kubinkaadmin',
                'password': '%9DdOWS5'
            }
        ]
    },
    {
        'name': 'Руза',
        'channels': ['https://t.me/SvetoforRuza'],
        'category': 'Светофор',
        'sites': [
            {
                'site': 'https://ruza-today.ru/v355/',
                'login': 'admin',
                'password': 'U*TU9ei%'
            }
        ]
    },
    {
        'name': 'Тучково',
        'channels': ['https://t.me/SvetoforTuchkovo'],
        'category': 'Светофор',
        'sites': [
            {
                'site': 'https://tuchkovo-online.ru/v355/',
                'login': 'admin',
                'password': 'U*TU9ei%'
            }
        ]
    },
    {
        'name': 'Дорохово',
        'channels': ['https://t.me/SvetoforDorohovo'],
        'category': 'Светофор',
        'sites': [
            {
                'site': 'https://dorohovo-online.ru/v355/',
                'login': 'Anton',
                'password': 'zhSeWpzuF)!DYGJucM22CX^K'

            }
        ]
    },
    {
        'name': 'Селятино',
        'channels': ['https://t.me/SvetoforSelyatino'],
        'category': 'Светофор',
        'sites': [
            {
                'site': 'https://selyatino-life.ru/v355/',
                'login': 'Nina',
                'password': 'zhSeWpzuF)!DYGJucM22CX^K'
            }
        ]
    }
]

count_message_new_chat = 2  # ограничения на "глубину" сообщений в новом чате

CHECK_EVERY = 5  # Пауза между проверками, в минутах

API_ID = 22731225

API_HASH = 'bb653ff0e9af5da92e55a033773dcf40'

ADMIN = ['@developer_telegrams']
